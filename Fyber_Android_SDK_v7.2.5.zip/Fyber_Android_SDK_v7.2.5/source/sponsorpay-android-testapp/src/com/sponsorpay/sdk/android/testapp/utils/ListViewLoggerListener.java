package com.sponsorpay.sdk.android.testapp.utils;

import android.app.Activity;

import com.sponsorpay.sdk.android.testapp.LoggerActivity;
import com.sponsorpay.utils.SPLoggerListener;
import com.sponsorpay.utils.SponsorPayLogger;
import com.sponsorpay.utils.SponsorPayLogger.Level;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * ListViewLoggerListener  class
 */
public class ListViewLoggerListener implements SPLoggerListener {

	private final int LOGG_LIST_SIZE = 300;

	public static ListViewLoggerListener INSTANCE = new ListViewLoggerListener();

	private LinkedList<SPLog> logs = new LinkedList<>();
	private LoggerListAdapter logsListViewAdapter;
	private Activity activity;

	private ListViewLoggerListener() {
	}

	@Override
	public void log(Level level, String tag, String message, Exception exception) {
		logs.addLast(new SPLog(level, tag, message, exception, new Date(System.currentTimeMillis())));
		if (logs.size() >= LOGG_LIST_SIZE) {
			logs.removeLast();
		}
		if (logsListViewAdapter != null) {
			this.activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					logsListViewAdapter.updateLogs(getArrayFromCircularArray());
				}
			});
		}
	}

	public void clear(List<SPLog> logsToDelete) {
		logs.removeAll(logsToDelete);
	}

	public void initListViewAdapter(LoggerActivity loggerActivity, LoggerListAdapter adapter) {
		activity = loggerActivity;
		logsListViewAdapter = adapter;
	}

	public List<SPLog> getArrayFromCircularArray() {
		return getFilteredArrayFromCircularArray(getAllLevels());
	}

	public List<SPLog> getFilteredArrayFromCircularArray(ArrayList<SponsorPayLogger.Level> filteredLogLevels) {
		List<SPLog> logsList = new ArrayList<>();

		for (SPLog log : logs) {
			if (filteredLogLevels.contains(log.getLogLeve())) {
				logsList.add(log);
			}
		}
		return logsList;
	}

	public ArrayList<Level> getAllLevels() {
		return new ArrayList<>(Arrays.asList(SponsorPayLogger.Level.values()));
	}

	public List<SPLog> getFilteredArrayFromCircularArray(boolean atLeastOnItemSelected, ArrayList<SponsorPayLogger.Level> filteredLevels) {
		List<SPLog> filteredLogs = new ArrayList<>();
		if (!atLeastOnItemSelected) {
			filteredLogs = getFilteredArrayFromCircularArray(filteredLevels);
		} else {
			for (SPLog log : logs) {
				if (log.isChecked()) {
					filteredLogs.add(log);
				}
			}
		}
		return filteredLogs;
	}
}
