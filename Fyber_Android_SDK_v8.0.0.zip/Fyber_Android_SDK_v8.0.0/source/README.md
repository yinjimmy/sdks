# Fyber Sample App

This is the Fyber Sample application that shows you the basic usage of the Fyber SDK

For more information, please visit the [Getting Started](http://developer.fyber.com/content/android/basics/getting-started-sdk/) guide.

## Get started

Rename the `gradle.properties.sample` file to `gradle.properties` and edit the variables to reflect your local settings.
