var searchData=
[
  ['addorigin',['addOrigin',['../classcom_1_1flurry_1_1android_1_1FlurryAgent.html#acec16f7d36eb681230c6b5b0e14d2fd9',1,'com.flurry.android.FlurryAgent.addOrigin(String originName, String originVersion)'],['../classcom_1_1flurry_1_1android_1_1FlurryAgent.html#a8d95422000f66360285a833a88038801',1,'com.flurry.android.FlurryAgent.addOrigin(String originName, String originVersion, Map&lt; String, String &gt; originParameters)']]]
];
