package com.sponsorpay.sdk.android.testapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ListView;

import com.sponsorpay.sdk.android.testapp.utils.ListViewLoggerListener;
import com.sponsorpay.sdk.android.testapp.utils.LoggerListAdapter;
import com.sponsorpay.sdk.android.testapp.utils.SPLog;
import com.sponsorpay.utils.SponsorPayLogger;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * LoggerActivity activity class
 */
public class LoggerActivity extends Activity {

	public static final String LOG_LEVEL_ALL = "All";
	public static final String LOG_LEVEL_DEBUG = "Debug";
	public static final String LOG_LEVEL_INDEX = "Info";
	public static final String LOG_LEVEL_WARNING = "Warning";
	public static final String LOG_LEVEL_ERROR = "Error";
	public static final String LOG_LEVEL_VERBOSE = "Verbose";

	private final int ALL_INDEX = 0;
	private final int DEBUG_INDEX = 1;
	private final int INFO_INDEX = 2;
	private final int WARNING_INDEX = 3;
	private final int ERROR_INDEX = 4;
	private final int VERBOSE_INDEX = 5;
	private final int NUMBER_OF_LOG_FILTERS = 5;

	private ListView listView;
	private boolean[] checkedLogs = new boolean[NUMBER_OF_LOG_FILTERS + 1];
	private CharSequence[] logFilters = new CharSequence[NUMBER_OF_LOG_FILTERS + 1];
	private LoggerListAdapter logsListViewAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_logger);
		listView = (ListView) findViewById(R.id.logs_list_view);
		initFilters();
		initListViewAdapter();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (isFinishing()) {
			resetSelectedLogs();
		}
	}

	public void initListViewAdapter() {
		logsListViewAdapter = new LoggerListAdapter(this, ListViewLoggerListener.INSTANCE.getArrayFromCircularArray());
		listView.setAdapter(logsListViewAdapter);
		listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
		listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
				List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(getFilteredLevels());
				filteredLogs.get(i).setChecked(!filteredLogs.get(i).isChecked());
				logsListViewAdapter.updateLogs(filteredLogs);
				return true;
			}
		});

		//single tap log selection after at least one log is selected
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
				List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(getFilteredLevels());
				boolean atLeastOnItemSelected = isAtLeastOnItemSelected();

				if (atLeastOnItemSelected) {
					filteredLogs.get(i).setChecked(!filteredLogs.get(i).isChecked());
					logsListViewAdapter.updateLogs(filteredLogs);
				}
			}
		});
		ListViewLoggerListener.INSTANCE.initListViewAdapter(this, logsListViewAdapter);
	}

	private void initFilters() {
		logFilters[ALL_INDEX] = LOG_LEVEL_ALL;
		logFilters[DEBUG_INDEX] = LOG_LEVEL_DEBUG;
		logFilters[INFO_INDEX] = LOG_LEVEL_INDEX;
		logFilters[WARNING_INDEX] = LOG_LEVEL_WARNING;
		logFilters[ERROR_INDEX] = LOG_LEVEL_ERROR;
		logFilters[VERBOSE_INDEX] = LOG_LEVEL_VERBOSE;

		for (int i = 0; i < checkedLogs.length; i++) {
			checkedLogs[i] = true;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu_logger, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		final AlertDialog.Builder builder = new AlertDialog.Builder(this);

		builder.setMultiChoiceItems(logFilters, checkedLogs, new DialogInterface.OnMultiChoiceClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int itemIndex, boolean check) {
				resetSelectedLogs();
				switch (itemIndex) {
					case ALL_INDEX:
						AlertDialog d = (AlertDialog) dialogInterface;
						ListView v = d.getListView();
						int i = 0;
						while (i < logFilters.length) {
							v.setItemChecked(i, check);
							checkedLogs[i] = check;
							i++;
						}
						break;
					case DEBUG_INDEX:
					case INFO_INDEX:
					case WARNING_INDEX:
					case ERROR_INDEX:
					case VERBOSE_INDEX:
						checkedLogs[itemIndex] = check;
						checkedLogs[ALL_INDEX] = false;
						AlertDialog ad = (AlertDialog) dialogInterface;
						ListView lv = ad.getListView();
						boolean allChecekd = areAllChecked(checkedLogs);
						lv.setItemChecked(ALL_INDEX, allChecekd);
					default:
						break;
				}
				updateLoggerFilters();
			}

			private boolean areAllChecked(boolean[] booleanArray) {
				int numberOfCheckedLevels = 0;
				for (boolean isLogChecked : booleanArray) {
					if (isLogChecked) {
						numberOfCheckedLevels++;
					}
				}
				return numberOfCheckedLevels >= booleanArray.length - 1;
			}
		});
		builder.show();

		return super.onMenuItemSelected(featureId, item);
	}

	private void resetSelectedLogs() {
		List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(getFilteredLevels());
		for (SPLog log : filteredLogs) {
			log.setChecked(false);
		}
		logsListViewAdapter.updateLogs(filteredLogs);
	}

	private void updateLoggerFilters() {
		updateListViewWithFilters(getFilteredLevels());
		CheckBox selectAllCheckbox = (CheckBox) findViewById(R.id.cb_select_all);
		selectAllCheckbox.setChecked(false);
	}

	private ArrayList<SponsorPayLogger.Level> getFilteredLevels() {
		ArrayList<SponsorPayLogger.Level> logLevels = new ArrayList<>();

		for (int i = 0; i < checkedLogs.length; i++) {
			if (checkedLogs[i]) {
				switch (i) {
					case DEBUG_INDEX:
						logLevels.add(SponsorPayLogger.Level.DEBUG);
						break;
					case INFO_INDEX:
						logLevels.add(SponsorPayLogger.Level.INFO);
						break;
					case WARNING_INDEX:
						logLevels.add(SponsorPayLogger.Level.WARNING);
						break;
					case ERROR_INDEX:
						logLevels.add(SponsorPayLogger.Level.ERROR);
						break;
					case VERBOSE_INDEX:
						logLevels.add(SponsorPayLogger.Level.VERBOSE);
						break;
				}
			}
		}
		return logLevels;
	}

	/**
	 * Triggered when the user clicks on the Top btn to scroll the log view to
	 * the very top
	 *
	 * @param v
	 */
	public void onScrollTopClick(View v) {
		int pos = 0;
		scrollListToPos(pos);
	}

	/**
	 * Triggered when the user clicks on the Bottom btn to scroll the log view
	 * to the very bottom
	 *
	 * @param v
	 */
	public void onScrollBottomClick(View v) {
		int pos = listView.getAdapter().getCount() - 1;
		scrollListToPos(pos);
	}

	/**
	 * Triggered when the user clicks on the clear btn to clear the scroll view
	 *
	 * @param v
	 */
	public void onClearLogClick(View v) {
		List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(getFilteredLevels());
		List<SPLog> logsToDelete = new ArrayList<>();

		if (!isAtLeastOnItemSelected()) {
			logsToDelete.addAll(filteredLogs);
			filteredLogs.clear();
		} else {
			for (SPLog log : filteredLogs) {
				if (log.isChecked()) {
					logsToDelete.add(log);
				}
			}
			filteredLogs.removeAll(logsToDelete);
		}
		ListViewLoggerListener.INSTANCE.clear(logsToDelete);
		logsListViewAdapter.updateLogs(filteredLogs);
	}

	/**
	 * Triggered when the user clicks on the Share btn to share the selected logs
	 *
	 * @param v
	 */
	public void onShareLogClick(View v) {
		Intent shareIntent = new Intent();
		shareIntent.setAction(Intent.ACTION_SEND);
		boolean atLeastOnItemSelected = isAtLeastOnItemSelected();
		List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(atLeastOnItemSelected, getFilteredLevels());
		String logsToShare = getLogsAsString(filteredLogs);
		shareIntent.putExtra(Intent.EXTRA_TEXT, logsToShare);
		shareIntent.setType("text/plain");
		startActivity(shareIntent);
	}

	private void scrollListToPos(int pos) {
		if (ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(getFilteredLevels()).size() < 50) {
			listView.smoothScrollToPosition(pos);
		} else {
			listView.setSelection(pos);
		}
	}

	public void onCheckboxSelectAllClicked(View v) {
		selectAllLogs(((CheckBox) v).isChecked(), getFilteredLevels());
	}

	public boolean isAtLeastOnItemSelected() {
		boolean atLeastOnItemSelected = false;
		List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(getFilteredLevels());
		for (SPLog filteredLog : filteredLogs) {
			atLeastOnItemSelected = atLeastOnItemSelected || filteredLog.isChecked();
		}
		return atLeastOnItemSelected;
	}

	public void selectAllLogs(boolean selectLog, ArrayList<SponsorPayLogger.Level> checkedLogs) {
		List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(checkedLogs);
		for (SPLog log : filteredLogs) {
			log.setChecked(selectLog);
		}
		logsListViewAdapter.updateLogs(filteredLogs);
	}

	public void updateListViewWithFilters(ArrayList<SponsorPayLogger.Level> checkedLogs) {
		List<SPLog> filteredLogs = ListViewLoggerListener.INSTANCE.getFilteredArrayFromCircularArray(checkedLogs);
		logsListViewAdapter.updateLogs(filteredLogs);
	}

	public String getLogsAsString(List<SPLog> filteredLogs) {
		String logsAsString = "";

		for (SPLog log : filteredLogs) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
			String date = simpleDateFormat.format(log.getLogTimeStamp());
			String tag = log.getLogTag();
			String msg = log.getMsg();

			String singleLogAsString = date + "\n" + "[" + tag + "]\n" + msg + "\n" + " -----------------------" + "\n";
			logsAsString += singleLogAsString;
		}
		return logsAsString;
	}
}
