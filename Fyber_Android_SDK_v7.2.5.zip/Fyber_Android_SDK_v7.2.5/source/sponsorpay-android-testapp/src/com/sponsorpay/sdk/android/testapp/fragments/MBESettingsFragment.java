package com.sponsorpay.sdk.android.testapp.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;

import com.sponsorpay.SponsorPay;
import com.sponsorpay.publisher.SponsorPayPublisher;
import com.sponsorpay.publisher.currency.SPCurrencyServerErrorResponse;
import com.sponsorpay.publisher.currency.SPCurrencyServerListener;
import com.sponsorpay.publisher.currency.SPCurrencyServerSuccessfulResponse;
import com.sponsorpay.publisher.mbe.SPBrandEngageClient;
import com.sponsorpay.publisher.mbe.SPBrandEngageRequestListener;
import com.sponsorpay.sdk.android.testapp.R;
import com.sponsorpay.sdk.android.testapp.SponsorpayAndroidTestAppActivity;
import com.sponsorpay.utils.SponsorPayLogger;
import com.sponsorpay.utils.StringUtils;

public class MBESettingsFragment extends AbstractSettingsFragment implements SPBrandEngageRequestListener {

	private static final String TAG = "MBESettingsFragment";

	private static final String MBE_CHECK_VCS = "MBE_CHECK_VCS";
	private static final String MBE_SHOW_REWARD_NOTIFICATION = "MBE_SHOW_REWARD_NOTIFICATION";
	private static final String MBE_CONSECUTIVE_REQUEST_NOTIFICATION = "MBE_CONSECUTIVE_REQUEST_NOTIFICATION";
	private static final String MBE_PLAY_AFTER_REQUEST_NOTIFICATION = "MBE_PLAY_AFTER_REQUEST_NOTIFICATION";
	private static final String PREFERENCES_FILE_NAME = "SponsorPayTestAppState";

	private static final int MBE_REQUEST_CODE = 8745;

	private Intent mIntent;
	private CheckBox mVCSCheckbox;
	private CheckBox mNotificationCheckbox;
	private CheckBox mConsecutiveRequestsCheckbox;
	private CheckBox mPlayAfterRequestCheckbox;
	private Button btnStart;
	private Button btnRequest;

	private boolean mAddVCSListener;
	private boolean mShowNotification;
	private boolean mConsecutiveRequests;
	private boolean mPlayAfterRequest;

	private String currencyId;

	private SponsorpayAndroidTestAppActivity mMainActivity;

	private SPCurrencyServerListener mVCSListener = new SPCurrencyServerListener() {

		@Override
		public void onSPCurrencyServerError(
				SPCurrencyServerErrorResponse response) {
			Log.e(TAG, "VCS error received - " + response.getErrorMessage());
		}

		@Override
		public void onSPCurrencyDeltaReceived(
				SPCurrencyServerSuccessfulResponse response) {
			Log.d(TAG, "VCS coins received - " + response.getDeltaOfCoins());
		}
	};

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		mMainActivity = (SponsorpayAndroidTestAppActivity) this.getActivity();

		View view = inflater.inflate(R.layout.fragment_settings_mbe, container, false);

		btnStart = ((Button) view.findViewById(R.id.mbe_start));
		btnRequest = ((Button) view.findViewById(R.id.mbe_request_offers));

		btnRequest.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				requestMBEOffers();
			}
		});

		btnStart.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				mMainActivity.fetchValuesFromFields();

				SponsorPayLogger.d(TAG, "Starting engagement");
				startEngament();
			}
		});

		return view;
	}

	private void requestMBEOffers() {
		mMainActivity.fetchValuesFromFields();
		SponsorPayLogger.d(TAG, "Requesting MBE offers...");
		btnRequest.setEnabled(false);
		btnStart.setEnabled(false);
		Context context = getActivity();
		SharedPreferences sharedPref = context.getSharedPreferences(PREFERENCES_FILE_NAME, Context.MODE_PRIVATE);
		String currencyName = sharedPref.getString(CurrencyFragment.VCS_CURRENCY_NAME, StringUtils.EMPTY_STRING);
		requestOffers(currencyName);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK) {
			switch (requestCode) {
				case MBE_REQUEST_CODE:
					String engagementResult = data.getStringExtra(SPBrandEngageClient.SP_ENGAGEMENT_STATUS);
					SponsorPayLogger.d(TAG, "SPBrandEngageClient closed with status - " + engagementResult);
					if (mConsecutiveRequests) {
						requestMBEOffers();
					}
					break;
				default:
					break;
			}
		}
	}

	@Override
	protected String getFragmentTitle() {
		return getResources().getString(R.string.mbe);
	}

	@Override
	protected void setValuesInFields() {
		mVCSCheckbox.setChecked(mAddVCSListener);
		mNotificationCheckbox.setChecked(mShowNotification);
		mConsecutiveRequestsCheckbox.setChecked(mConsecutiveRequests);
		mPlayAfterRequestCheckbox.setChecked(mPlayAfterRequest);
	}

	@Override
	protected void bindViews() {
		mVCSCheckbox = (CheckBox) findViewById(R.id.mbe_add_vcs_listener_checkbox);
		mNotificationCheckbox = (CheckBox) findViewById(R.id.mbe_show_notification_checkbox);
		mConsecutiveRequestsCheckbox = (CheckBox) findViewById(R.id.mbe_consecutive_requests_checkbox);
		mPlayAfterRequestCheckbox = (CheckBox) findViewById(R.id.mbe_play_after_request);
	}

	@Override
	protected void fetchValuesFromFields() {
		mAddVCSListener = mVCSCheckbox.isChecked();
		mShowNotification = mNotificationCheckbox.isChecked();
		mConsecutiveRequests = mConsecutiveRequestsCheckbox.isChecked();
		mPlayAfterRequest = mPlayAfterRequestCheckbox.isChecked();
	}

	@Override
	protected void readPreferences(SharedPreferences prefs) {
		mAddVCSListener = prefs.getBoolean(MBE_CHECK_VCS, true);
		mShowNotification = prefs.getBoolean(MBE_SHOW_REWARD_NOTIFICATION, true);
		mConsecutiveRequests = prefs.getBoolean(MBE_CONSECUTIVE_REQUEST_NOTIFICATION, false);
		mPlayAfterRequest = prefs.getBoolean(MBE_PLAY_AFTER_REQUEST_NOTIFICATION, false);

		currencyId = prefs.getString(CurrencyFragment.VCS_CURRENCY_ID, StringUtils.EMPTY_STRING);
	}

	@Override
	protected void storePreferences(Editor prefsEditor) {
		prefsEditor.putBoolean(MBE_CHECK_VCS, mAddVCSListener);
		prefsEditor.putBoolean(MBE_SHOW_REWARD_NOTIFICATION, mShowNotification);
		prefsEditor.putBoolean(MBE_CONSECUTIVE_REQUEST_NOTIFICATION, mConsecutiveRequests);
		prefsEditor.putBoolean(MBE_PLAY_AFTER_REQUEST_NOTIFICATION, mPlayAfterRequest);
	}

	public void requestOffers(String currencyName) {
		fetchValuesFromFields();
		try {
			String credentialsToken = SponsorPay.getCurrentCredentials().getCredentialsToken();

			SPBrandEngageClient.INSTANCE.setShowRewardsNotification(mShowNotification);

			SPCurrencyServerListener vcsListener = mAddVCSListener ? mVCSListener : null;
			SponsorPayPublisher.getIntentForMBEActivity(credentialsToken, getActivity(), this,
					currencyName, null, vcsListener, currencyId, SponsorpayAndroidTestAppActivity.mPlacementId);


		} catch (RuntimeException ex) {
			btnRequest.setEnabled(true);
			btnStart.setEnabled(false);
			showCancellableAlertBox("Exception from SDK", ex.getMessage());
			Log.e(SponsorpayAndroidTestAppActivity.class.toString(), "SponsorPay SDK Exception: ",
					ex);
		}
	}

	public void startEngament() {
		if (mIntent != null && SPBrandEngageClient.INSTANCE.canStartEngagement()) {
			SponsorPayLogger.d(TAG, "Starting MBE engagement...");
			btnStart.setEnabled(false);
			startActivityForResult(mIntent, MBE_REQUEST_CODE);
			mIntent = null;
		}
	}

	@Override
	public void onSPBrandEngageOffersAvailable(Intent spBrandEngageActivity) {
		btnRequest.setEnabled(true);
		btnStart.setEnabled(true);
		SponsorPayLogger.d(TAG, "SPBrandEngage - offers are available");
		mIntent = spBrandEngageActivity;
		if (mPlayAfterRequest) {
			startEngament();
		}
	}

	@Override
	public void onSPBrandEngageOffersNotAvailable() {
		btnRequest.setEnabled(true);
		btnStart.setEnabled(false);
		SponsorPayLogger.d(TAG, "SPBrandEngage - no offers for the moment");
	}

	@Override
	public void onSPBrandEngageError(String errorMessage) {
		btnRequest.setEnabled(true);
		btnStart.setEnabled(false);
		SponsorPayLogger.e(TAG, "SPBrandEngage - an error occurred:\n" + errorMessage);
	}

}
