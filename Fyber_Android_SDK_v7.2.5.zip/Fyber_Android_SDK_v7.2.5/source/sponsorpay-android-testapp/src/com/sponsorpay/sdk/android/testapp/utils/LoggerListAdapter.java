package com.sponsorpay.sdk.android.testapp.utils;


import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.sponsorpay.sdk.android.testapp.R;
import com.sponsorpay.utils.SponsorPayLogger;
import com.sponsorpay.utils.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * LoggerListAdapter  class
 */
public class LoggerListAdapter extends ArrayAdapter<SPLog> {

	private List<SPLog> logs = new ArrayList<SPLog>();

	public LoggerListAdapter(Context context, List<SPLog> logs) {
		super(context, -1, logs);
		this.logs = logs;
	}

	public void updateLogs(List<SPLog> logs) {
		this.logs.clear();
		this.logs.addAll(logs);
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return logs.size();
	}

	@Override
	public SPLog getItem(int i) {
		return logs.get(i);
	}

	@Override
	public long getItemId(int i) {
		return i;
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {

		View rowView = view;

		if (rowView == null) {
			LayoutInflater vi;
			vi = LayoutInflater.from(getContext());
			rowView = vi.inflate(R.layout.log_view, null);

			ViewHolder holder = new ViewHolder();
			holder.logContainer = rowView.findViewById(R.id.log_view_container);
			holder.logDate = (TextView) rowView.findViewById(R.id.log_date);
			holder.logDTag = (TextView) rowView.findViewById(R.id.log_tag);
			holder.logMsg = (TextView) rowView.findViewById(R.id.log_message);
			rowView.setTag(holder);
		}

		final ViewHolder holder = (ViewHolder) rowView.getTag();

		SPLog log = getItem(i);

		final int logColor = getLogBackGroundColor(log.getLogLeve());

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
		String date = simpleDateFormat.format(log.getLogTimeStamp());

		String msg = log.getMsg() != null ? log.getMsg() : StringUtils.EMPTY_STRING;
		msg += log.getException() != null ? " - Exception " + log.getException().getLocalizedMessage() : StringUtils.EMPTY_STRING;

		holder.logDate.setText(date);
		holder.logDTag.setText("[" + log.getLogTag() + "]");
		holder.logMsg.setText(msg);

		holder.logDate.setTextColor(Color.GRAY);
		holder.logDTag.setTextColor(logColor);
		holder.logMsg.setTextColor(logColor);

		if (logs.get(i).isChecked()) {
			holder.logContainer.setBackgroundColor(Color.parseColor("#d7d7d7"));
		} else {
			holder.logContainer.setBackgroundColor(Color.WHITE);
		}

		return rowView;
	}

	static class ViewHolder {

		View logContainer;
		TextView logDate;
		TextView logDTag;
		TextView logMsg;
	}

	private int getLogBackGroundColor(SponsorPayLogger.Level level) {

		int color;
		switch (level) {
			case DEBUG:
				color = Color.BLUE;
				break;
			case INFO:
				color = Color.rgb(0xEB, 0x6E, 0x01);
				break;
			case WARNING:
				color = Color.rgb(0xFF, 0xA5, 0x00);
				break;
			case ERROR:
				color = Color.RED;
				break;
			case VERBOSE:
			default:
				color = Color.BLACK;
				break;
		}
		return color;

	}
}
