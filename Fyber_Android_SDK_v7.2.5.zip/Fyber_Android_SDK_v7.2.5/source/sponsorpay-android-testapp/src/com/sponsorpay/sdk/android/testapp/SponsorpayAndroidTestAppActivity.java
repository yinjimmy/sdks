/**
 * SponsorPay Android SDK
 * <p/>
 * Copyright 2011 - 2014 SponsorPay. All rights reserved.
 */

package com.sponsorpay.sdk.android.testapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.sponsorpay.SponsorPay;
import com.sponsorpay.credentials.SPCredentials;
import com.sponsorpay.mediation.SPMediationConfigurationFiles;
import com.sponsorpay.mediation.SPMediationConfigurator;
import com.sponsorpay.publisher.SponsorPayPublisher;
import com.sponsorpay.publisher.SponsorPayPublisher.UIStringIdentifier;
import com.sponsorpay.sdk.android.testapp.fragments.ActionsSettingsFragment;
import com.sponsorpay.sdk.android.testapp.fragments.CurrencyFragment;
import com.sponsorpay.sdk.android.testapp.fragments.InterstitialFragment;
import com.sponsorpay.sdk.android.testapp.fragments.LauncherFragment;
import com.sponsorpay.sdk.android.testapp.fragments.MBESettingsFragment;
import com.sponsorpay.sdk.android.testapp.fragments.MediationConfigsListAdapter;
import com.sponsorpay.sdk.android.testapp.utils.ListViewLoggerListener;
import com.sponsorpay.sdk.android.testapp.utils.TestAppCountryParameterProvider;
import com.sponsorpay.sdk.android.testapp.utils.TestAppParametersProvider;
import com.sponsorpay.sdk.android.testapp.utils.TestAppUrlsProvider;
import com.sponsorpay.utils.SponsorPayBaseUrlProvider;
import com.sponsorpay.utils.SponsorPayLogger;
import com.sponsorpay.utils.SponsorPayParametersProvider;
import com.sponsorpay.utils.StringUtils;

import java.lang.reflect.Method;
import java.util.EnumMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Example activity in order to show the usage of Sponsorpay Android SDK.
 */
public class SponsorpayAndroidTestAppActivity extends FragmentActivity {
	private static final String TAG = SponsorpayAndroidTestAppActivity.class.getSimpleName();

	/**
	 * Shared preferences file name. Stores the values entered into the UI
	 * fields.
	 */
	private static final String PREFERENCES_FILE_NAME = "SponsorPayTestAppState";

	private static final String APP_ID_PREFS_KEY = "APP_ID";
	private static final String USER_ID_PREFS_KEY = "USER_ID";
	private static final String SECURITY_TOKEN_PREFS_KEY = "SECURITY_TOKEN";
	private static final String PLACEMENT_ID_PREFS_KEY = "PLACEMENT_ID";
	private static final String USE_STAGING_URLS_PREFS_KEY = "USE_STAGING_URLS";
	private static final String USE_PLAIN_HTTPS_PREF_KEY = "USE_PLAIN_HTTP";

	private static final int MAIN_SETTINGS_ACTIVITY_CODE = 3962;

	public static String mPlacementId;

	private EditText mAppIdField;
	private EditText mUserIdField;
	private EditText mSecurityTokenField;
	private EditText mPlacementIdField;
	private EditText mCountryCodeField;
	private TextView mCredentialsInfo;

	private CheckBox mUseStagingUrlsCheckBox;
	private CheckBox mUsePlainHttpCheckBox;

	private boolean mShouldStayOpen;
	private boolean mShowToastOnSuccessfulVCSRequest;

	/**
	 * Called when the activity is first created. See {@link Activity}.
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		SponsorPayLogger.enableLogging(true);
		SponsorPayBaseUrlProvider.setProviderOverride(TestAppUrlsProvider.INSTANCE);
		SponsorPayParametersProvider.addParametersProvider(TestAppParametersProvider.INSTANCE);
		SponsorPayParametersProvider.addParametersProvider(TestAppCountryParameterProvider.INSTANCE);

		additionalLaunch();

		setContentView(R.layout.main);

		bindViews();
		setCustomErrorMessages();

		createLauncherFragment();

		setApplicationTitle();

		((TextView) findViewById(R.id.sdk_version_string)).setText("Fyber SDK v. " + SponsorPay.RELEASE_VERSION_STRING);

		SponsorPayLogger.addLoggerListener(ListViewLoggerListener.INSTANCE);

	}

	private void setApplicationTitle() {

		PackageInfo pInfo;
		ApplicationInfo aInfo;
		String title = getTitle().toString() + " (";
		Boolean addBeta = false;

		try {
			pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
			aInfo = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
			title += pInfo.versionCode;
			addBeta = aInfo.metaData.getBoolean("beta");
		} catch (NameNotFoundException e) {
			SponsorPayLogger.e(TAG, e.getMessage(), e);
		} catch (NullPointerException e) {
			// Meta data not found
		}

		Spannable titleSpan = new SpannableString(title + (addBeta ? " BETA" : "") + ")");

		titleSpan.setSpan(new ForegroundColorSpan(Color.GRAY), getTitle().length(), titleSpan.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		setTitle(titleSpan);
	}

	private void createLauncherFragment() {
		Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_placeholder);
		if (fragment == null) {
			FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
			LauncherFragment launcherFragment = new LauncherFragment();
			transaction.add(R.id.fragment_placeholder, launcherFragment);
			transaction.commit();
		}
	}

	protected void bindViews() {
		mAppIdField = (EditText) findViewById(R.id.app_id_field);
		mUserIdField = (EditText) findViewById(R.id.user_id_field);
		mSecurityTokenField = (EditText) findViewById(R.id.security_token_field);
		mPlacementIdField = (EditText) findViewById(R.id.placement_id_field);
		mCountryCodeField = (EditText) findViewById(R.id.country_code_field);

		mUseStagingUrlsCheckBox = (CheckBox) findViewById(R.id.use_staging_urls_checkbox);
		mUsePlainHttpCheckBox = (CheckBox) findViewById(R.id.use_http_checkbox);
		if (!TestAppUrlsProvider.INSTANCE.isStagingAvailble()) {
			mUseStagingUrlsCheckBox.setVisibility(View.GONE);
			mUsePlainHttpCheckBox.setVisibility(View.GONE);
		}

		mCredentialsInfo = (TextView) findViewById(R.id.credentials_info);
	}

	public void onSettingsButtonClick(View v) {
		fetchValuesFromFields();
		Intent intent = new Intent(getApplicationContext(), MainSettingsActivity.class);
		intent.putExtra(MainSettingsActivity.PREFERENCES_EXTRA, PREFERENCES_FILE_NAME);
		startActivityForResult(intent, MAIN_SETTINGS_ACTIVITY_CODE);
	}

	private void shutdownAndAwaitTermination(ExecutorService pool) {
		pool.shutdown();
		try {
			if (!pool.awaitTermination(15, TimeUnit.SECONDS)) {
				pool.shutdownNow();
			}
		} catch (InterruptedException ie) {
			ie.printStackTrace();
			pool.shutdownNow();
		}
	}

	@Override
	protected void onPause() {
		// Save the state of the UI fields into the app preferences.
		fetchValuesFromFields();

		SharedPreferences prefs = getSharedPreferences(PREFERENCES_FILE_NAME, Context.MODE_PRIVATE);
		Editor prefsEditor = prefs.edit();

		prefsEditor.putString(APP_ID_PREFS_KEY, mAppIdField.getText().toString());
		prefsEditor.putString(USER_ID_PREFS_KEY, mUserIdField.getText().toString());
		prefsEditor.putString(SECURITY_TOKEN_PREFS_KEY, mSecurityTokenField.getText().toString());

		prefsEditor.putString(PLACEMENT_ID_PREFS_KEY, mPlacementId);
		prefsEditor.putBoolean(USE_STAGING_URLS_PREFS_KEY, mUseStagingUrlsCheckBox.isChecked());
		prefsEditor.putBoolean(USE_PLAIN_HTTPS_PREF_KEY, mUsePlainHttpCheckBox.isChecked());

		prefsEditor.commit();

		super.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();

		// Recover the state of the UI fields from the app preferences.
		SharedPreferences prefs = getSharedPreferences(PREFERENCES_FILE_NAME, Context.MODE_PRIVATE);

		String overridingAppId = prefs.getString(APP_ID_PREFS_KEY, StringUtils.EMPTY_STRING);

		String userId = prefs.getString(USER_ID_PREFS_KEY, StringUtils.EMPTY_STRING);
		String securityToken = prefs.getString(SECURITY_TOKEN_PREFS_KEY, StringUtils.EMPTY_STRING);

		String mOverridingUrl = prefs
				.getString(MainSettingsActivity.OVERRIDING_URL_PREFS_KEY, StringUtils.EMPTY_STRING);

		mPlacementId = prefs.getString(PLACEMENT_ID_PREFS_KEY, StringUtils.EMPTY_STRING);
		mShouldStayOpen = prefs.getBoolean(MainSettingsActivity.KEEP_OFFERWALL_OPEN_PREFS_KEY, true);
		mShowToastOnSuccessfulVCSRequest = prefs.getBoolean(MainSettingsActivity.SHOW_TOAST_VCS_REQUEST_PREFS_KEY,
				true);

		ImageView settingsButton = (ImageView) findViewById(R.id.settings_button);

		updateVCSToastNotification();

		mUseStagingUrlsCheckBox.setChecked(prefs.getBoolean(USE_STAGING_URLS_PREFS_KEY, false));
		mUsePlainHttpCheckBox.setChecked(prefs.getBoolean(USE_PLAIN_HTTPS_PREF_KEY, false));

		if (mOverridingUrl.equals(StringUtils.EMPTY_STRING)) {
			settingsButton.setBackgroundResource(Color.TRANSPARENT);
		} else {
			settingsButton.setBackgroundColor(Color.parseColor("#FBC809"));
		}

		TestAppUrlsProvider.INSTANCE.setOverridingUrl(mOverridingUrl);
		TestAppParametersProvider.INSTANCE.setParameters(MainSettingsActivity.readParameters(prefs));

		TestAppUrlsProvider.INSTANCE.shouldUseStaging(mUseStagingUrlsCheckBox.isChecked());
		TestAppUrlsProvider.INSTANCE.shouldUsePlainHttp(mUsePlainHttpCheckBox.isChecked());

		String infoLocation = prefs.getString(MainSettingsActivity.ADAPTERS_INFO_LOCATION_PREFS_KEY, "");
		String configLocation = prefs.getString(MainSettingsActivity.ADAPTERS_CONFIG_LOCATION_PREFS_KEY, "");

		SPMediationConfigurationFiles.setAdaptersInfoLocation(infoLocation);
		SPMediationConfigurationFiles.setAdaptersConfigLocation(configLocation);

		boolean startSdkOnAppStart = prefs.getBoolean(MainSettingsActivity.START_SDK_ON_APP_START_PREFS_KEY, false);

		setValuesInFields(overridingAppId, userId, securityToken);

		if (startSdkOnAppStart) {
			try {
				createNewCredentials();
			} catch (RuntimeException e) {
				SponsorPayLogger.d(TAG, e.getLocalizedMessage());
			}
		}

	}

	private void updateVCSToastNotification() {
		SponsorPayPublisher.displayNotificationForSuccessfullCoinRequest(mShowToastOnSuccessfulVCSRequest);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Is this response intended for a fragment?
		// from
		// http://blog.tgrigsby.com/2012/04/18/android-fragment-frustration.aspx
		int fragmentIndex = (requestCode >> 16);
		if (fragmentIndex != 0) {
			// Yes. Pass it on...
			super.onActivityResult(requestCode, resultCode, data);
		} else if (resultCode == RESULT_OK) {
			switch (requestCode) {
				case MAIN_SETTINGS_ACTIVITY_CODE:
					mShouldStayOpen = data.getBooleanExtra(MainSettingsActivity.KEEP_OFFERWALL_OPEN_EXTRA, true);
					mShowToastOnSuccessfulVCSRequest = data.getBooleanExtra(MainSettingsActivity.SHOW_TOAST_VCS_REQUEST_EXTRA, true);
					updateVCSToastNotification();
					break;
				default:
					break;
			}
		}
	}

	/**
	 * Sets one custom UI message in the SDK to demonstrate the use of
	 * SponsorPayPublisher.setCustomUIStrings();
	 */
	private void setCustomErrorMessages() {
		EnumMap<UIStringIdentifier, Integer> customUIStrings = new EnumMap<>(UIStringIdentifier.class);
		customUIStrings.put(UIStringIdentifier.ERROR_DIALOG_TITLE, R.string.custom_error_message);
		SponsorPayPublisher.setCustomUIStrings(customUIStrings, getApplicationContext());
	}

	/**
	 * Fetches user provided values from the state of the UI text fields and
	 * text boxes.
	 */
	public void fetchValuesFromFields() {
		mPlacementId = mPlacementIdField.getText().toString();
		TestAppUrlsProvider.INSTANCE.shouldUseStaging(mUseStagingUrlsCheckBox.isChecked());
		TestAppUrlsProvider.INSTANCE.shouldUsePlainHttp(mUsePlainHttpCheckBox.isChecked());
		TestAppCountryParameterProvider.INSTANCE.useCountry(mCountryCodeField.getText().toString());
	}

	/**
	 * Sets values in the state of the UI text fields and text boxes.
	 */
	private void setValuesInFields() {
		try {
			SPCredentials credentials = SponsorPay.getCurrentCredentials();
			setValuesInFields(credentials.getAppId(), credentials.getUserId(), credentials.getSecurityToken());
			setCredentialsInfo();
		} catch (RuntimeException e) {
			SponsorPayLogger.d(TAG, "There's no current credentials.");
		}
	}

	private void setValuesInFields(String overridingAppId, String userId, String securityToken) {
		mAppIdField.setText(overridingAppId);
		mUserIdField.setText(userId);
		mSecurityTokenField.setText(securityToken);
		mPlacementIdField.setText(mPlacementId);
	}

	private void setCredentialsInfo() {
		try {
			mCredentialsInfo.setText(SponsorPay.getCurrentCredentials().toString());
		} catch (RuntimeException e) {
			SponsorPayLogger.d(TAG, "There are no credentials yet, unable to send the callback.");
		}
	}


	/**
	 * Triggered when the user clicks on the create new credentials button.
	 *
	 * @param v
	 */
	public void onCreateNewCredentialsClick(View v) {
		try {
			createNewCredentials();
		} catch (RuntimeException e) {
			showCancellableAlertBox("Exception from SDK", e.getMessage());
			SponsorPayLogger.e(TAG, "SponsorPay SDK Exception: ", e);
		}
	}

	/**
	 * Creates new credentials from the values in the text fields
	 */
	private void createNewCredentials() {
		fetchValuesFromFields();
		String overridingAppId = mAppIdField.getText().toString();
		String userId = mUserIdField.getText().toString();
		String securityToken = mSecurityTokenField.getText().toString();
		SponsorPay.start(overridingAppId, userId, securityToken, this);
		SponsorPayLogger.d(TAG, "Credentials updated");

		setCredentialsInfo();
	}

	/**
	 * Triggered when the user clicks on the launch offer wall button.
	 *
	 * @param v
	 */
	public void onLaunchOfferwallClick(View v) {
		fetchValuesFromFields();
		try {
			String currencyName = getPrefsStore().getString(CurrencyFragment.VCS_CURRENCY_NAME, StringUtils.EMPTY_STRING);
			startActivityForResult(SponsorPayPublisher.getIntentForOfferWallActivity(getApplicationContext(),
					mShouldStayOpen, currencyName, null, mPlacementId), 5689);
		} catch (RuntimeException ex) {
			showCancellableAlertBox("Exception from SDK", ex.getMessage());
			SponsorPayLogger.e(TAG, "SponsorPay SDK Exception: ", ex);
		}
	}

	/**
	 * Triggered when the user clicks on the send action button.
	 */
	public void onSendActionClick(View v) {
		getCurrentFragment(ActionsSettingsFragment.class).sendActionCompleted();
	}

	// Interstitial

	public void onRequestAdsClick(View v) {
		getCurrentFragment(InterstitialFragment.class).requestAds();
	}

	public void onShowAdClick(View v) {
		getCurrentFragment(InterstitialFragment.class).showAds();
	}

	public void onLoggerClick(View v) {
		showLogger();
	}

	public void showLogger() {
		Intent intent = new Intent(this, LoggerActivity.class);
		startActivity(intent);
	}


	/**
	 * Shows an alert box with the provided title and message and a unique
	 * button to cancel it.
	 *
	 * @param title The title for the alert box.
	 * @param text  The text message to show inside the alert box.
	 */
	public void showCancellableAlertBox(String title, String text) {
		AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
		dialogBuilder.setTitle(title).setMessage(text).setCancelable(true);
		dialogBuilder.show();
	}

	public SharedPreferences getPrefsStore() {
		return getSharedPreferences(PREFERENCES_FILE_NAME, Context.MODE_PRIVATE);
	}

	// FRAGMENTS stuff

	@SuppressWarnings("unchecked")
	private <T extends Fragment> T getCurrentFragment(Class<T> type) {
		fetchValuesFromFields();
		Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_placeholder);
		if (fragment.getClass().isAssignableFrom(type)) {
			return (T) fragment;
		}
		return null;
	}

	protected void replaceFragment(Fragment newFragment) {
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

		// Replace whatever is in the fragment_container view with this
		// fragment, and add the transaction to the back stack

		// transaction.setCustomAnimations(android.R.anim.slide_in_left,
		// android.R.anim.slide_out_right);
		transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);

		newFragment.setRetainInstance(true);
		transaction.replace(R.id.fragment_placeholder, newFragment);

		transaction.addToBackStack(null);

		// Commit the transaction
		transaction.commit();
	}

	public void onRequestNewCoinsClick(View view) {
		replaceFragment(new CurrencyFragment());
	}

	public void onActionsClick(View view) {
		replaceFragment(new ActionsSettingsFragment());
	}

	public void onMBEClick(View view) {
		replaceFragment(new MBESettingsFragment());
	}

	public void onInterstitialClick(View view) {
		replaceFragment(new InterstitialFragment());
	}

	// SP User
	public void onSPUserClick(View v) {
		Intent intent = new Intent(getApplicationContext(), SPUserActivity.class);
		startActivity(intent);
	}

	// Mediation Settings 

	public void onMediationSettingsClick(View v) {
		Intent intent = new Intent(getApplicationContext(), MediationConfigsActivity.class);
		startActivity(intent);
	}

	public void onVideoMockMediationClick(View view) {
		startConfigurationActivity(SPMediationConfigurator.getConfiguration("MockMediatedNetwork", "video.class.name",
				String.class));
	}

	public void onInterstitialMockMediationClick(View view) {
		startConfigurationActivity(SPMediationConfigurator.getConfiguration("MockMediatedNetwork",
				"interstitial.class.name", String.class));
	}

	private void startConfigurationActivity(String className) {
		try {
			@SuppressWarnings("unchecked")
			Class<Activity> forName = (Class<Activity>) Class.forName(className);
			Intent intent = new Intent(getApplicationContext(), forName);
			startActivity(intent);
		} catch (ClassNotFoundException e) {
			SponsorPayLogger.e(TAG, e.getMessage(), e);
		}
	}

	//
	public void notifyMediationAdaptersList(List<String> adapters) {
		MediationConfigsListAdapter.setAdapters(adapters);
		LauncherFragment launcherFragment = getCurrentFragment(LauncherFragment.class);
		if (launcherFragment != null) {
			launcherFragment.refreshLayout();
		}
	}

	private void additionalLaunch() {
		try {
			Properties classes = new Properties();
			classes.load(this.getClass().getResourceAsStream("/classes.properties"));
			//calling this reflexively
			for (Object value : classes.values()) {
				try {
					Class<?> startClass = Class.forName(value.toString());

					Method startMethod = startClass.getMethod("start", Context.class);
					startMethod.invoke(null, this);
				} catch (Exception e) {
				}
			}

		} catch (Exception e) {
		}
	}

}
