package com.sponsorpay.sdk.android.testapp.utils;


import com.sponsorpay.utils.SponsorPayLogger;

import java.util.Date;

/**
 * SPLog class
 */
public class SPLog {

	private SponsorPayLogger.Level logLeve;
	private String tag;
	private String msg;
	private Exception exception;
	private Date logTimeStamp;
	private boolean isChecked;

	public SPLog(SponsorPayLogger.Level logLeve, String tag, String msg, Exception exception, Date logTimeStamp) {
		this.logLeve = logLeve;
		this.tag = tag;
		this.msg = msg;
		this.exception = exception;
		this.logTimeStamp = logTimeStamp;
	}

	public SponsorPayLogger.Level getLogLeve() {
		return logLeve;
	}

	public String getLogTag() {
		return tag;
	}

	public String getMsg() {
		return msg;
	}

	public Exception getException() {
		return exception;
	}

	public Date getLogTimeStamp() {
		return logTimeStamp;
	}

	public boolean isChecked() {
		return isChecked;
	}

	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}
}
